<?php
// Nama folder yang akan diunduh
$folderName = 'PORTOFOLIO'; // Pastikan untuk tidak ada spasi di nama folder

// Mengambil path lengkap folder
$folderPath = realpath($folderName);

if ($folderPath === false) {
    die('Folder tidak ditemukan.');
}

// Membuat file ZIP sementara
$zipFile = tempnam(sys_get_temp_dir(), 'zip');
$zip = new ZipArchive();
if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
    die('Tidak dapat membuat file ZIP.');
}

// Menambahkan semua file dan subfolder ke dalam file ZIP
addFilesToZip($folderPath, $zip, strlen(dirname($folderPath)) + 1);

$zip->close();

// Mengatur header untuk memulai pengunduhan
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . basename($folderName) . '.zip"');
header('Content-Length: ' . filesize($zipFile));

// Membaca dan mengirimkan konten file ZIP
readfile($zipFile);

// Menghapus file ZIP sementara
unlink($zipFile);

function addFilesToZip($dirPath, $zip, $basePathLength) {
    if (is_dir($dirPath)) {
        $dir = opendir($dirPath);
        while (($file = readdir($dir)) !== false) {
            if ($file !== '.' && $file !== '..') {
                $filePath = $dirPath . '/' . $file;
                if (is_dir($filePath)) {
                    addFilesToZip($filePath, $zip, $basePathLength);
                } else {
                    $localPath = substr($filePath, $basePathLength);
                    $zip->addFile($filePath, $localPath);
                }
            }
        }
        closedir($dir);
    }
}
?>
